# README #

This is the source code for http://kronologger.com
you can see http://kronologger.com to know
how this code works

Kronologger.com is web apps platform to connecting
people to their neighbourhood,
No Login, No registration.
Apps will detect geolocation based on HTML5 geodetection location.

Kronologger.com also have an API at folder
http://kronologger.com/API

to test client, you can try at
folder /clienttestAPI

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact