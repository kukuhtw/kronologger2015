    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
   <div class="panel-heading">
   <div class="panel panel-info">
   <div class="panel-heading"><h5 class="panel-title">

 <a name="disclaimer"></a>						About / Disclaimer						</div>
<p class="animated slideInUp">
<br>Kronologger.com is Location Based services for three functions
<br>
<br>1. Location Based Market Place
<br>2. Location Based File Sharing
<br>3. Location Based Bulletin Board
<br>
<br>Kronologger.com as a Location Based Market Place is allow you
<br>to sell and buy your used good things / second hands good things
<br>like house, car, gadget, home appliance, etc to people around you.
<br>only people nearby can see your messages
<br>
<br>Kronologger.com as a Location Based File Sharing is allow you
<br>to share your files to people around you.
<br>if you need only share to specified person or groups, you can protect your file attachment with password.
<br>if you sales, you can share material promo like voucher/brochure to people nearby
<br>
<br>Kronologger.com as a Location Based Bulletin Board is allow you
<br>to announce news/promo/discount material to people around you.
<br>to announce local news to your Neighbourhood
<br>
<br>No Login, No Sign up, No Registration required
<br>area is in radius 1 kilometres
<br>contact email : kukuhtw at kukuhtw dot com
<br>Follow our twitter account at <a href="http://twitter.com/kronologger" target="_new">http://twitter.com/kronologger</a>
<br>
<br>Kronologger.com is used to be microblogging services since 2006-2010,
<Br>now has been pivot to become
<br>Location Based Services since april 21st,2015
<br>
</p>

</div>
</div>