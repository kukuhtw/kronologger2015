    <p>&nbsp;</p>
   <div class="panel-heading">
   <div class="panel panel-info">
   <div class="panel-heading"><h5 class="panel-title">

<a name="disclaimer"></a>Share and Recommend</div>
<p>&nbsp;</p>
<p>
<div class="fb-like" data-href="https://kronologger.com" data-layout="standard" data-action="recommend" data-show-faces="true" data-share="true"></div>
</p>
<br>
<div class="fb-send" data-href="http://kronologger.com/"></div>
<br><br>
<script src="//platform.linkedin.com/in.js" type="text/javascript"> lang: en_US</script>
<script type="IN/Share" data-url="http://kronologger.com" data-counter="right"></script>
<br><br>
<!-- Place this tag in your head or just before your close body tag. -->
<script src="https://apis.google.com/js/platform.js" async defer></script>
<!-- Place this tag where you want the share button to render. -->
<div class="g-plus" data-action="share" data-height="15" data-href="http://kronologger.com"></div>
<p>&nbsp;</p>
<br>
</p>

</div>
</div>

