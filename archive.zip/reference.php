   <div class="panel-heading">
   <div class="panel panel-info">
   <div class="panel-heading"><h5 class="panel-title">
 <a name="disclaimer">What they said about Kronologger.com </div>
<p>&nbsp;</p>
<p><a href="http://netnesia.com/2015/04/kronologger.html" target="_new">http://netnesia.com/2015/04/kronologger.html</a>
<p>&nbsp;</p>
if you write about kronologger.com , let me know,
we will link back to you
</div>
</div>
