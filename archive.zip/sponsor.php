<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- kronologger 468x60 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:468px;height:60px"
     data-ad-client="ca-pub-1898453520217107"
     data-ad-slot="4598195898"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<br>
