<body bgcolor="#FFFFFF">
<img src="secret.png">
</body>