-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 30, 2015 at 09:37 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kronologger2015`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `commentid` bigint(20) NOT NULL AUTO_INCREMENT,
  `msgid` bigint(20) NOT NULL,
  `contentcomment` text NOT NULL,
  `commentdate` datetime NOT NULL,
  PRIMARY KEY (`commentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`commentid`, `msgid`, `contentcomment`, `commentdate`) VALUES
(1, 56, 'testing kasih comment pertamax', '2015-04-20 10:56:48'),
(2, 56, 'testing kasih comment kedua', '2015-04-20 10:56:57'),
(3, 46, 'bro/sis, ini passwordnya apa ya ?', '2015-04-20 10:57:16'),
(4, 42, 'wah...lagu jadul... mantap simple plan', '2015-04-20 10:57:38'),
(5, 44, 'maling kurang ajar !!!!', '2015-04-20 10:58:02'),
(6, 42, 'I am just a kid....', '2015-04-20 11:02:32'),
(7, 39, 'bisa dong', '2015-04-20 11:14:25'),
(8, 36, 'opo iki', '2015-04-20 21:59:28'),
(9, 49, 'wah berfungsi juga nih website', '2015-04-21 00:10:00'),
(10, 61, 'yakin? sumpee lo ? ah masa sih...', '2015-04-21 05:00:45'),
(11, 61, 'kantornya wilayah senayan ya. sama dong', '2015-04-21 05:17:49'),
(12, 64, 'aplikasi untuk berbagi file ke lokasi sekitar', '2015-04-21 20:48:08'),
(13, 36, 'Test Kronologer', '2015-04-21 21:00:15'),
(14, 36, 'tes', '2015-04-21 21:12:15'),
(15, 64, 'siapa pengguna first media? internetnya lemot gak?', '2015-04-22 01:36:02'),
(16, 66, 'barusan baca status di fb mas.. lngsung nyoba haha... nice inpoh! ', '2015-04-22 03:30:13'),
(17, 64, 'kadang lemot, kadang lamban', '2015-04-22 05:52:14'),
(18, 69, 'eh siapa nih.. tetangga sebelah ya', '2015-04-22 08:48:04'),
(19, 64, 'kadang lelet kadang mati', '2015-04-22 08:50:53'),
(20, 58, 'keren.. lagunya bisa langsung dicopy ke dropbox', '2015-04-22 08:55:03'),
(21, 68, 'jogja....', '2015-04-22 09:06:37'),
(22, 66, 'cerita dua jam yg lalu masih ada disni? yg mosting masih dikit ya??', '2015-04-22 10:30:26'),
(23, 64, 'tebak yg psoting ini siapa? termasuk yg komen ini siapa? :D #kode', '2015-04-22 10:30:57'),
(24, 69, 'kamu siapa? hahaha login biar eksist belum ready yah? ', '2015-04-22 10:31:36'),
(25, 69, 'aku penunggu gedung cyber', '2015-04-22 10:38:10'),
(26, 69, 'aku baru saja terdeteksi di http://setandisini.com', '2015-04-22 10:43:30'),
(27, 68, 'lagi di mm juice ring road utara ya', '2015-04-22 10:56:19'),
(28, 67, 'di sekitaran pasar johar baru ya ?', '2015-04-22 10:57:20'),
(29, 66, 'muncul postingnya berdasarkan area ya ?', '2015-04-22 17:18:07'),
(30, 72, 'ada yang lain kak ?', '2015-04-23 00:53:21'),
(31, 36, 'tes', '2015-04-23 01:57:34'),
(32, 72, 'ini aja dulu diabisin', '2015-04-23 02:03:38'),
(33, 71, 'iya betul betul', '2015-04-23 04:31:27'),
(34, 73, 'test kasih komet...', '2015-04-24 00:08:15'),
(35, 71, 'jadi ini anonimus gitu ya? hehe', '2015-04-24 19:28:39'),
(36, 83, 'ngetes komen', '2015-04-24 19:34:51'),
(37, 83, 'ngetes komen', '2015-04-24 19:38:25'),
(38, 82, 'wah ternyata bisa tuh', '2015-04-24 22:23:21'),
(39, 83, 'eh aku di bandung nih, di ciampelas walk', '2015-04-24 22:25:34'),
(40, 82, 'kalau comment nggK bisa kirim emoticon', '2015-04-25 01:43:55'),
(41, 84, 'gambanya bisa dicopy ke dropbox. mantap', '2015-04-25 01:44:36'),
(42, 96, 'ih apaan nih', '2015-04-28 21:29:02');

-- --------------------------------------------------------

--
-- Table structure for table `shout`
--

CREATE TABLE IF NOT EXISTS `shout` (
  `msgid` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` int(11) NOT NULL,
  `lat_shout` double(18,10) NOT NULL,
  `lon_shout` double(18,10) NOT NULL,
  `contentmsg` text NOT NULL,
  `fileattachment` text NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  `msgdate` datetime NOT NULL,
  `passprotected` varchar(255) NOT NULL,
  `isPassword` tinyint(1) NOT NULL,
  `isAttachment` tinyint(1) NOT NULL,
  `isthumbnail` tinyint(1) NOT NULL,
  `desctime` char(255) NOT NULL,
  PRIMARY KEY (`msgid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=407 ;

--
-- Dumping data for table `shout`
--

INSERT INTO `shout` (`msgid`, `appid`, `lat_shout`, `lon_shout`, `contentmsg`, `fileattachment`, `thumbnail`, `msgdate`, `passprotected`, `isPassword`, `isAttachment`, `isthumbnail`, `desctime`) VALUES
(10, 0, -6.2401541000, 106.9063606000, 'ini juga bisa pake hyperlink automatis, test ya <a target=_new href="http://kumpulblogger.com">http://kumpulblogger.com</a>', '', '', '2015-04-15 12:44:39', '', 0, 0, 0, ''),
(9, 0, -6.2401541000, 106.9063606000, 'test upload file dll', '', '', '2015-04-15 12:43:22', '', 0, 0, 0, ''),
(8, 0, -6.2401541000, 106.9063606000, 'coba upload gambar penguin', 'files/8606013846-2252419992-60836137365.jpg', 'thumbnail/th-8606013846-2252419992-60836137365.jpg', '2015-04-15 12:42:11', '', 0, 1, 1, ''),
(7, 0, -6.2401541000, 106.9063606000, 'testing posting gambar animated gif', 'files/4702737383-6253099069-31380124856.gif', '', '2015-04-15 12:41:36', '', 0, 1, 0, ''),
(12, 0, -8.2369597800, 116.9073057200, 'gambar apa ini', 'files/6602462404-1899155369-51052758191.jpg', 'thumbnail/th-6602462404-1899155369-51052758191.jpg', '2015-04-15 12:51:44', '', 0, 1, 1, ''),
(13, 0, -6.2401541000, 106.9063606000, 'qrcode u', 'files/6782767777-5650892486-28265176574.png', 'thumbnail/th-6782767777-5650892486-28265176574.png', '2015-04-15 16:49:25', '', 0, 1, 1, ''),
(14, 0, -6.2401541000, 106.9063606000, 'test lagi deh ya', '', '', '2015-04-15 17:17:51', '', 0, 0, 0, ''),
(15, 0, -6.2369639000, 106.9074543000, 'anter anak sekolah', '', '', '2015-04-15 17:40:24', '', 0, 0, 0, ''),
(16, 0, -6.2488995000, 106.9291145000, 'anter anak sekolah dan bayarab', '', '', '2015-04-15 17:40:49', '', 0, 0, 0, ''),
(18, 0, -6.2401541000, 106.9063606000, 'testing lagi pake upload gambar qrcode', 'files/6915585934-6846789662-91060932306.png', 'thumbnail/th-6915585934-6846789662-91060932306.png', '2015-04-15 18:48:43', '', 0, 1, 1, ''),
(20, 0, -6.2369597800, 106.9073057200, 'sedang mencoba kronologger', 'files/4768420206-200038339-52115600277.jpg', 'thumbnail/th-4768420206-200038339-52115600277.jpg', '2015-04-15 20:08:20', '', 0, 1, 1, ''),
(22, 0, -6.2373476000, 106.8986465000, 'lagi di klender stasiun kereta', '', '', '2015-04-15 21:46:07', '', 0, 0, 0, ''),
(23, 0, -6.2098758000, 106.8497557000, 'sudah sampai stasiun manggarai', '', '', '2015-04-15 22:01:15', '', 0, 0, 0, ''),
(24, 0, -6.2005693000, 106.8159118000, 'sudah sampai di karet staaiun', '', '', '2015-04-15 22:25:09', '', 0, 0, 0, ''),
(25, 0, -6.2214803542, 106.7910932174, 'akhirnya sampai kantor deh', '', '', '2015-04-15 22:47:34', '', 0, 0, 0, ''),
(26, 0, -6.2231720000, 106.8037460000, 'hahaha...nih gw kasih gambar', 'files/8680018908-6301288637-68261352274.jpg', 'thumbnail/th-8680018908-6301288637-68261352274.jpg', '2015-04-15 23:45:42', '', 0, 1, 1, ''),
(27, 0, -6.2231720000, 106.8037460000, 'comic tentang perbedaan jobs dan startup', 'files/4516967926-1514926460-65876446664.jpg', 'thumbnail/th-4516967926-1514926460-65876446664.jpg', '2015-04-16 00:12:50', '', 0, 1, 1, ''),
(28, 0, -6.2075699903, 106.7974097077, 'capenya.. stasiun palmerah', '', '', '2015-04-16 05:14:04', '', 0, 0, 0, ''),
(29, 0, -6.1854651000, 106.8107932000, 'sekarang di tanah abang stasiun', '', '', '2015-04-16 05:34:03', '', 0, 0, 0, ''),
(30, 0, -6.2130561000, 106.8991674000, 'sudah sampai klender', '', '', '2015-04-16 06:08:52', '', 0, 0, 0, ''),
(31, 0, -6.2401341000, 106.9063606000, 'berangkat dulu ya', '', '', '2015-04-16 17:18:59', '', 0, 0, 0, ''),
(32, 0, -6.2131564000, 106.8992721000, 'ngetem di jatinrgara', '', '', '2015-04-16 21:33:18', '', 0, 0, 0, ''),
(33, 0, -6.2098907000, 106.8502513000, 'manggarai manggarai', '', '', '2015-04-16 21:47:48', '', 0, 0, 0, ''),
(34, 0, -6.2025432000, 106.8093650000, 'macetnya pejompongan', '', '', '2015-04-16 22:09:52', '', 0, 0, 0, ''),
(35, 0, -6.2395332000, 106.7981271000, 'menuju kemang villages', '', '', '2015-04-17 03:45:58', '', 0, 0, 0, ''),
(57, 0, -6.2401341000, 106.9063606000, 'upload mp3 surat cintaku yang pertama dari vina panduwinata', 'files/6750108711-2718769768-57059288304.mp3', '', '2015-04-20 11:41:33', '', 0, 1, 0, ''),
(38, 0, -6.1950540000, 106.8219735000, 'lagi di grand indonesia', '', '', '2015-04-18 05:27:09', '', 0, 0, 0, ''),
(39, 0, -6.2369711000, 106.9073212000, 'mantep dah... bisa posting jualan juga ya disini', '', '', '2015-04-18 23:41:31', '', 0, 0, 0, ''),
(40, 0, -6.2369649000, 106.9073174000, 'test gif', 'files/6785127977-3232684103-83940804377.gif', '', '2015-04-19 00:48:43', '', 0, 1, 0, ''),
(41, 0, -6.2401341000, 106.9063606000, 'mencoba upload file movie mp4', 'files/4546229383-3715449665-76358301844.mp4', '', '2015-04-19 02:35:34', '', 0, 1, 0, ''),
(42, 0, -6.2401341000, 106.9063606000, 'test upload mp3 file, i am just a kid from simple plan', 'files/6059957887-5623631468-65469694603.mp3', '', '2015-04-19 04:44:08', '', 0, 1, 0, ''),
(43, 0, -6.2401341000, 106.9063606000, 'mp3 , lagunya andra and the backbone, hitamku. selamat menikmati.', 'files/9969126712-6985941063-81872171582.mp3', '', '2015-04-19 05:05:47', '', 0, 1, 0, ''),
(44, 0, -6.2369744000, 106.9073222000, 'nih ada maling', 'files/1854621996-6121257432-28359188978.mp4', '', '2015-04-19 05:14:22', '', 0, 1, 0, ''),
(45, 0, -6.2401341000, 106.9063606000, 'ini file jpg dipasangi password, hanya dibagi ke orang-orang tertenu saja', 'files/6629269318-3619086510-72875206079.jpg', 'thumbnail/th-6629269318-3619086510-72875206079.jpg', '2015-04-19 08:19:33', 'f7b1c776f72e90b28153f216c1e3b1f5', 1, 1, 1, ''),
(46, 0, -6.2401341000, 106.9063606000, 'ini file txt, dibagikan ke orang-orang internal saja. dipasangin password ah', 'files/459244955-9375588018-11175835319.txt', '', '2015-04-19 08:32:15', 'f7b1c776f72e90b28153f216c1e3b1f5', 1, 1, 0, ''),
(47, 0, -6.1856554000, 106.8836399000, 'setlist the adams', 'files/1646079203-6458589583-67629942624.jpg', 'thumbnail/th-1646079203-6458589583-67629942624.jpg', '2015-04-19 12:04:07', '', 0, 1, 1, ''),
(48, 0, -6.1856274000, 106.8836505000, 'Sulap', 'files/6476018457-2255274649-48581757490.mp4', '', '2015-04-19 12:10:22', '', 0, 1, 0, ''),
(49, 0, -6.2235730000, 106.7883531000, 'informasi pengalihan arus lalu lintas sekitar sudirman thamrin pada 19 sampai 24 april 2015. ', 'files/4321783306-9783813026-12807881413.jpg', 'thumbnail/th-4321783306-9783813026-12807881413.jpg', '2015-04-20 01:11:52', '', 0, 1, 1, ''),
(50, 0, -6.1820633000, 106.8302639000, 'alow\\r\\n', 'files/3180497820-2628048402-50322660059.jpg', 'thumbnail/th-3180497820-2628048402-50322660059.jpg', '2015-04-20 01:42:37', '', 0, 1, 1, ''),
(52, 0, -6.2235730000, 106.7883531000, 'lagu jadul dari third eye blind - semi charmed life', 'files/4142104467-155041465-66623978363.mp3', '', '2015-04-20 02:35:52', '', 0, 1, 0, ''),
(53, 0, -6.1856563000, 106.8836461000, 'Ada menu mpek-mpek di Tjikini', '', '', '2015-04-20 04:28:51', '', 0, 0, 0, ''),
(54, 0, -6.2558725000, 106.8024698000, 'good quote', 'files/9106029886-2520533572-29457844747.jpg', 'thumbnail/th-9106029886-2520533572-29457844747.jpg', '2015-04-20 04:30:44', '', 0, 1, 1, ''),
(55, 0, -6.2074938000, 106.7974287000, 'foto selfi. malu ah. dikasih password ya supaya orang lain nggak bisa lihat', 'files/1638770206-7262313938-14088970097.jpg', 'thumbnail/th-1638770206-7262313938-14088970097.jpg', '2015-04-20 05:17:58', '8afd09e1a46165a4acbe426a78f5f524', 1, 1, 1, ''),
(56, 0, -6.2401541000, 106.9063606000, 'Company Profile Perusahaan terkemuka di sekitar sini', 'files/9189547137-9679276486-16452205647.pdf', '', '2015-04-20 09:25:26', '8afd09e1a46165a4acbe426a78f5f524', 1, 1, 0, ''),
(58, 0, -6.1894592000, 106.8827542000, 'you got some fucking attitude.', 'files/6151301064-909462944-93673159228.mp3', '', '2015-04-20 11:48:58', '', 0, 1, 0, ''),
(59, 0, -6.2489272000, 106.9290460000, 'tumben jalanan kali malang jam segini kok sepi ya', '', '', '2015-04-20 17:45:40', '', 0, 0, 0, ''),
(60, 0, -6.2235730000, 106.7883531000, 'oke boleh aplikasinya, mantap sekali, ini jajal kirim gambar photo perempuan cantik seksi, tapi dipassword ya...', 'files/9256493114-1561218687-20446651429.jpg', 'thumbnail/th-9256493114-1561218687-20446651429.jpg', '2015-04-21 00:53:30', '8afd09e1a46165a4acbe426a78f5f524', 1, 1, 1, ''),
(61, 0, -6.2207895000, 106.7914975000, 'Ada mas kukuh TW disini.', '', '', '2015-04-21 04:47:48', '', 0, 0, 0, ''),
(62, 0, -6.2098907000, 106.8502513000, 'stasiun manggarai rame banget. penumpang menumpuk. keretanya nggak dateng dateng', '', '', '2015-04-21 06:06:49', '', 0, 0, 0, ''),
(63, 0, -6.2401341000, 106.9063606000, 'ini game flash, dicoba deh...lucu lho', 'files/2832238218-5988256712-82497046934.swf', '', '2015-04-21 08:39:33', '', 0, 1, 0, ''),
(64, 0, -6.2087634000, 106.8455990000, 'ini apaan ... cc apaan.co ', '', '', '2015-04-21 20:41:20', '', 0, 0, 0, ''),
(65, 0, -6.1855556000, 106.8108039000, 'mari belanja di grosirbersama.com , grosir online bermarkas di tanah abang', '', '', '2015-04-21 22:34:03', '', 0, 0, 0, ''),
(66, 0, -6.1965891126, 106.8161280025, 'hampir kecopetan di bus s608 pas mau turun di patal senayan. 2 orang menghalangi orang turun. 1 orang di belakang udah raba raba kantong', '', '', '2015-04-21 23:40:01', '', 0, 0, 0, ''),
(67, 0, -6.3046641000, 106.9361864000, 'Aman', '', '', '2015-04-22 03:58:41', '', 0, 0, 0, ''),
(68, 0, -7.7500435000, 110.3729068000, 'Ngoahahaha', '', '', '2015-04-22 04:24:22', '', 0, 0, 0, ''),
(69, 0, -6.2389531000, 106.8242571000, 'what happen aya naon .. ', '', '', '2015-04-22 08:43:31', '', 0, 0, 0, ''),
(70, 0, -6.2131651000, 106.8992386000, 'kalau bisa kirim file dan pesan dari sms dan mms, bakalan oke banget nih', '', '', '2015-04-22 22:20:22', '', 0, 0, 0, ''),
(71, 0, -6.2099143000, 106.8498481000, 'testing menggunakan kronologger. bisa dibikin banyak variasi penggunaan nih', '', '', '2015-04-22 23:02:23', '', 0, 0, 0, ''),
(72, 0, -6.2235730000, 106.7883531000, 'Challenging Big Brand .... ini materinya... pelajari ya', 'files/6217336319-4945466546-37967482442.pdf', '', '2015-04-23 00:34:42', '', 0, 1, 0, ''),
(73, 0, -6.2198832000, 106.7922145000, 'ada kecelakaan di rel kereta patal senayan jam 10 pagi hari ini. perempuan ditabrak kereta', '', '', '2015-04-23 02:04:57', '', 0, 0, 0, ''),
(74, 0, -6.2415856138, 106.6272926331, 'lagi di summarecon mall serpong, borong tas kresek', '', '', '2015-04-23 23:43:45', '', 0, 0, 0, ''),
(83, 0, -6.8943343000, 107.6070666000, 'Haloo, Bandung mana suaranya?', '', '', '2015-04-24 19:34:21', '', 0, 0, 0, ''),
(76, 0, -6.5147141143, 107.4585628510, 'Purwakarta..... adakah orang di sekitaran sini ?', '', '', '2015-04-23 23:46:34', '', 0, 0, 0, ''),
(81, 0, -6.3449215298, 106.7371129990, 'kuliah di universitas pamulang', '', '', '2015-04-23 23:51:19', '', 0, 0, 0, ''),
(78, 0, -7.8059868939, 110.3637599945, 'jalan-jalan ke jogjakarta, lihat keraton', '', '', '2015-04-23 23:48:14', '', 0, 0, 0, ''),
(82, 0, -6.2087634000, 106.8455990000, 'coba dulu, kalau di komputer gak bisa kedeteksi ya lokasinya?', '', '', '2015-04-24 19:31:04', '', 0, 0, 0, ''),
(84, 0, -6.2248833000, 106.8544184000, 'nyoba kirim gambar ya', 'files/446653199-8074521278-81343484390.jpg', 'thumbnail/th-446653199-8074521278-81343484390.jpg', '2015-04-25 01:43:07', '', 0, 1, 1, ''),
(85, 0, -6.1794388000, 106.7923308000, 'mall taman anggrek. jalan jalan malam minggu', '', '', '2015-04-25 02:52:24', '', 0, 0, 0, ''),
(86, 0, -6.2401341000, 106.9063606000, 'pengumuman untuk warga pondok bambu. cek file attachment ini ya', 'files/1444335906-7815624545-66083977464.jpg', 'thumbnail/th-1444335906-7815624545-66083977464.jpg', '2015-04-25 08:40:32', '', 0, 1, 1, ''),
(87, 0, -6.2401341000, 106.9063606000, 'testing upload files xls', 'files/1093265434-943213613-217713436.xls', '', '2015-04-25 23:26:48', 'f7b1c776f72e90b28153f216c1e3b1f5', 1, 1, 0, ''),
(88, 0, -6.2401341000, 106.9063606000, 'testing upload zipfile', 'files/468487003-1208504544-587581405.zip', '', '2015-04-25 23:29:55', 'f7b1c776f72e90b28153f216c1e3b1f5', 1, 1, 0, ''),
(89, 0, -6.2401341000, 106.9063606000, 'testete', 'files/1057850278-586092861-449859477.jpg', 'thumbnail/th-1057850278-586092861-449859477.jpg', '2015-04-26 01:49:13', '', 0, 1, 1, ''),
(90, 0, -6.2401341000, 106.9063606000, 'dfdsf dsf dsfdsf', 'files/470939814-1101312377-296740297.jpg', 'thumbnail/th-470939814-1101312377-296740297.jpg', '2015-04-26 01:51:28', '', 0, 1, 1, ''),
(91, 0, -6.2401341000, 106.9063606000, 'saassasaa', 'files/1075407245-560962300-671579908.jpg', 'thumbnail/th-1075407245-560962300-671579908.jpg', '2015-04-26 01:52:35', '', 0, 1, 1, ''),
(92, 0, -6.2401341000, 106.9063606000, 'dsfdsfdsfdsfds', 'files/1028029254-1147184256-466592394.jpg', 'thumbnail/th-1028029254-1147184256-466592394.jpg', '2015-04-26 01:56:59', '', 0, 1, 1, ''),
(93, 0, -6.2401341000, 106.9063606000, 'chart', 'files/999240992-1292072263-424852855.jpg', 'thumbnail/th-999240992-1292072263-424852855.jpg', '2015-04-26 01:59:46', '', 0, 1, 1, ''),
(94, 0, -6.2401341000, 106.9063606000, 'ghjghjh', 'files/593150073-1202867381-266762032.jpg', 'thumbnail/th-593150073-1202867381-266762032.jpg', '2015-04-26 02:00:05', '', 0, 1, 1, ''),
(95, 0, -6.2401341000, 106.9063606000, 'tesitn lagi ya', '', '', '2015-04-26 09:22:18', '', 0, 0, 0, ''),
(96, 0, -6.2401541000, 106.9063606000, 'troll rugby', 'files/189899251-321619533-859686097.mp4', '', '2015-04-27 23:05:23', '', 0, 1, 0, ''),
(97, 0, -6.2269934000, 106.8731878000, 'testing attach gambar', 'files/488109495-350967208-692356923.jpg', 'thumbnail/th-488109495-350967208-692356923.jpg', '2015-05-01 19:41:55', 'f7b1c776f72e90b28153f216c1e3b1f5', 1, 1, 1, ''),
(98, 0, -6.2269934000, 106.8731878000, 'test attach foto tanpa password', 'files/86622976-1050061526-628170787.jpg', 'thumbnail/th-86622976-1050061526-628170787.jpg', '2015-05-01 19:42:44', '', 0, 1, 1, ''),
(99, 0, -6.2269934000, 106.8731878000, 'test kirim attachment txt dengan password', 'files/194030302-66871389-625796271.txt', '', '2015-05-01 19:43:32', 'f7b1c776f72e90b28153f216c1e3b1f5', 1, 1, 0, ''),
(234, 1, -6.2401341000, 106.9063606000, 'Test Dari google chrome%2C dari sini sih pasti bisa', 'files/538585774-1336265903-721927068.jpg', 'thumbnail/th-538585774-1336265903-721927068.jpg', '2015-05-03 17:10:21', '8afd09e1a46165a4acbe426a78f5f524', 1, 1, 1, ''),
(119, 1, -6.2269934000, 106.8731878000, 'Testing Posting API ke #2 Tanpa atachment', '', '', '2015-05-02 12:53:17', '', 0, 0, 0, ''),
(121, 1, -6.2269934000, 106.8731878000, 'Testing Posting API ke 4 Dengan Attachmetn File Zip', 'files/511260593-1244048796-698664231.zip', '', '2015-05-02 12:57:02', '', 0, 1, 0, ''),
(122, 1, -6.2269934000, 106.8731878000, 'Testing Posting API ke 5 Dengan Attachment File XLS', '', '', '2015-05-02 12:58:09', '', 0, 0, 0, ''),
(123, 1, -6.2269934000, 106.8731878000, 'Testing Posting API ke 6 Dengan Attachment File XLSX', 'files/221527610-794753968-436688333.xlsx', '', '2015-05-02 12:58:54', '', 0, 1, 0, ''),
(124, 1, -6.2269934000, 106.8731878000, 'Testing Posting API ke 7 Dengan Attachment File txt pake password', 'files/312023446-105341801-328017125.txt', '', '2015-05-02 12:59:53', 'f7b1c776f72e90b28153f216c1e3b1f5', 1, 1, 0, ''),
(133, 1, -6.2269934000, 106.8731878000, 'Testing Posting API ke 18 Dengan Attachment File jpg pake password', 'files/828964234-644142734-1099326704.jpg', 'thumbnail/th-828964234-644142734-1099326704.jpg', '2015-05-02 13:23:28', 'f7b1c776f72e90b28153f216c1e3b1f5', 1, 1, 1, ''),
(134, 1, -6.2269934000, 106.8731878000, 'Testing Posting API ke 19 Dengan Attachment File pdf pake password', 'files/247992156-528774528-306052852.pdf', '', '2015-05-02 13:24:29', 'f7b1c776f72e90b28153f216c1e3b1f5', 1, 1, 0, ''),
(135, 1, -6.2269934000, 106.8731878000, 'Testing Posting API ke 20 Dengan Attachment File pdf NGGAK pake password', 'files/911972540-504590667-1110642757.pdf', '', '2015-05-02 13:25:01', '', 0, 1, 0, ''),
(136, 1, -6.2269934000, 106.8731878000, 'Testing Posting API ke 21 Dengan Attachment File txt NGGAK pake password', 'files/837054209-909046379-843917827.txt', '', '2015-05-02 13:27:15', '', 0, 1, 0, ''),
(137, 1, -6.2269934000, 106.8731878000, 'Testing Posting API ke 21 Dengan Attachment File JPG', 'files/342188725-815581350-1102294849.jpg', 'thumbnail/th-342188725-815581350-1102294849.jpg', '2015-05-02 13:27:55', '', 0, 1, 1, ''),
(138, 1, -6.2401341000, 106.9063606000, 'Test Dari Apps Ruasjalan , test 1', '', '', '2015-05-02 16:20:24', '8afd09e1a46165a4acbe426a78f5f524', 1, 0, 0, ''),
(139, 1, -6.2401341000, 106.9063606000, 'test dari web localhost ruasjalan', '', '', '2015-05-02 16:31:13', '', 0, 0, 0, ''),
(238, 1, -6.2401341000, 106.9063606000, 'Test Dari google chrome%2C dari sini sih pasti bisa ke2', 'files/517112915-295628337-772571042.jpg', 'thumbnail/th-517112915-295628337-772571042.jpg', '2015-05-03 17:19:03', '8afd09e1a46165a4acbe426a78f5f524', 1, 1, 1, ''),
(145, 1, -6.2401341000, 106.9063606000, 'Test Dari Apps Ruasjalan %2C test 2 dari googlechrome', 'files/776551524-262967216-723485344.jpg', 'thumbnail/th-776551524-262967216-723485344.jpg', '2015-05-02 16:41:05', '8afd09e1a46165a4acbe426a78f5f524', 1, 1, 1, ''),
(171, 1, -6.2401341000, 106.9063606000, 'Test Dari Apps Ruasjalan %2C tes3 dari googlechrome', 'files/975487449-994292337-553967162.jpg', 'thumbnail/th-975487449-994292337-553967162.jpg', '2015-05-02 18:16:22', '8afd09e1a46165a4acbe426a78f5f524', 1, 1, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `thirdpartyapps`
--

CREATE TABLE IF NOT EXISTS `thirdpartyapps` (
  `appid` int(11) NOT NULL AUTO_INCREMENT,
  `appname` text NOT NULL,
  `secretkey` text NOT NULL,
  `devname` varchar(255) NOT NULL,
  `devemail` varchar(255) NOT NULL,
  `regdate` datetime NOT NULL,
  PRIMARY KEY (`appid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `thirdpartyapps`
--

INSERT INTO `thirdpartyapps` (`appid`, `appname`, `secretkey`, `devname`, `devemail`, `regdate`) VALUES
(1, 'Demo', 'Demo', 'Demo', 'kukuhtw@gmail.com', '2015-05-01 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
